#coding=utf-8

## Parte 1
## Temas:
# - GUI que hereda de MainWindow
# - QLabel 
# - QPushbutton

import sys
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QPushButton

#creamos ventana
class HelloWorld(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.resize(500,300)
        self.setWindowTitle("Hola Mundo")
        # el padre de la ventana
        self.label = QLabel(self)
        # pasamos las coordenadas (0,0) es lado izq superior
        self.label.setGeometry(50,50,400,50)
        #alinear el texto en el centro
        self.label.setAlignment(Qt.AlignCenter)
        
        #utilizar codigo html y css (estilo del documento)
        self.label.setText( "<div style='color:red; font-size:30px;'>" +
                            "Hola Mundo!"+
                            "</div>")
        
        #el boton
        self.boton = QPushButton(self)
        self.boton.setGeometry(200,120,100,50)
        self.boton.setText("Close")
        
                #al hacer click se cierra
        self.boton.clicked.connect(self.close)
        
        
        #el boton de inicio
        self.boton = QPushButton(self)
        self.boton.setGeometry(100,20,100,50)
        self.boton.setText("Start")

        
        #al hacer click se cierra
        self.boton.clicked.connect(self.close)
        
        
        
        
        #para que sea ejecutable explicitamente el archivo
if __name__ == "__main__":
    
    # encargada de manejar las ventanas, el administrador de todo
    APP = QApplication(sys.argv)
    
    # para ejecutar la ventana
    GUI = HelloWorld()
    GUI.show()
    
    #Equivalente a While
    sys.exit(APP.exec_())
    
    
        
