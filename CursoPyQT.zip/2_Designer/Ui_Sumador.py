# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Sumador.ui'
#
# Created by: PyQt5 UI code generator 5.12.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(535, 394)
        MainWindow.setUnifiedTitleAndToolBarOnMac(True)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.lineEdit1 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit1.setGeometry(QtCore.QRect(70, 10, 411, 101))
        font = QtGui.QFont()
        font.setPointSize(48)
        self.lineEdit1.setFont(font)
        self.lineEdit1.setText("")
        self.lineEdit1.setAlignment(QtCore.Qt.AlignCenter)
        self.lineEdit1.setObjectName("lineEdit1")
        self.lineEdit2 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit2.setGeometry(QtCore.QRect(70, 120, 411, 101))
        font = QtGui.QFont()
        font.setPointSize(48)
        self.lineEdit2.setFont(font)
        self.lineEdit2.setText("")
        self.lineEdit2.setAlignment(QtCore.Qt.AlignCenter)
        self.lineEdit2.setObjectName("lineEdit2")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(220, 220, 88, 34))
        self.pushButton.setObjectName("pushButton")
        self.resultado = QtWidgets.QLineEdit(self.centralwidget)
        self.resultado.setGeometry(QtCore.QRect(70, 250, 411, 101))
        font = QtGui.QFont()
        font.setPointSize(48)
        self.resultado.setFont(font)
        self.resultado.setText("")
        self.resultado.setAlignment(QtCore.Qt.AlignCenter)
        self.resultado.setObjectName("resultado")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 535, 30))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Sumador"))
        self.lineEdit1.setPlaceholderText(_translate("MainWindow", "num1"))
        self.lineEdit2.setPlaceholderText(_translate("MainWindow", "num 2"))
        self.pushButton.setText(_translate("MainWindow", "Suma"))
        self.resultado.setPlaceholderText(_translate("MainWindow", "resultado"))


