#coding=utf-8
import sys

# # Temas:

# - Importar GUI desde QtDesigner
# - QLineEdit (Recibir input como texto)
# - Añadir Métodos (y conectarlos)
# - Mostrar un Diálogo Hijo

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from Ui_Sumador import Ui_MainWindow

class Sumador(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        
        # llamando el nombre del boton
        self.pushButton.clicked.connect(self.sumar)
        
    def sumar(self):
        try:
            #leer de las cajas
            n1 = int(self.lineEdit1.text())
            n2 = int(self.lineEdit2.text())
            
            #sumar
            n3 = n1 + n2
            
            #mostrar resultados
            self.resultado.setText(str(n3))
        except ValueError:
            QMessageBox.critical(self,"ERROR", "Valor inválido")
            self.lineEdit1.setText("")
            self.lineEdit2.setText("")

if __name__ == "__main__":
    APP = QApplication(sys.argv)

    GUI = Sumador()
    GUI.show()

    sys.exit(APP.exec_())
